from pysinewave import SineWave
from time import sleep

sw = SineWave()
sw.play()
sleep(10)
